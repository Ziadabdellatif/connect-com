import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { insertClientSchema, type InsertClient } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { 
  User, 
  Phone, 
  Building, 
  MapPin, 
  Hash, 
  DollarSign, 
  Star, 
  FileText, 
  Save, 
  Loader2,
  CheckCircle2 
} from 'lucide-react';
import { validateEgyptianPhone, openWhatsApp } from '@/lib/utils';

interface ClientFormProps {
  marketerId: number;
}

export default function ClientForm({ marketerId }: ClientFormProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [lastClientData, setLastClientData] = useState<any>(null);
  const { toast } = useToast();

  // Google Apps Script endpoint
  const GOOGLE_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbwdQVVeFKDrapLgcOQ-vv6dBOnvYa16mNpP8qssTdtMb7GOgm6e1ihVjrdo8U-w_Ozi/exec';

  const form = useForm<InsertClient>({
    resolver: zodResolver(insertClientSchema),
    defaultValues: {
      marketerId,
      clientName: '',
      clientPhone: '',
      propertyType: '',
      areaCity: '',
      unitCode: '',
      budgetRange: '',
      interestLevel: '',
      notes: '',
    },
  });

  const onSubmit = async (data: InsertClient) => {
    if (!validateEgyptianPhone(data.clientPhone)) {
      toast({
        title: "خطأ في رقم الهاتف",
        description: "يجب أن يبدأ الرقم بـ 01 ويتكون من 11 رقمًا",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      // Save to local database
      const response = await apiRequest('POST', '/api/clients', data);
      const client = await response.json();
      
      // Also send to Google Sheets via Apps Script
      try {
        const response = await fetch(GOOGLE_SCRIPT_URL, {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          body: JSON.stringify({
            referrerName: 'المسوق ' + marketerId,
            referrerPhone: '01000000000',
            clientName: data.clientName,
            clientPhone: data.clientPhone,
            propertyType: data.propertyType,
            areaCity: data.areaCity,
            unitCode: data.unitCode,
            notes: data.notes || ''
          })
        });
        
        if (!response.ok) {
          throw new Error(`Google Sheets sync failed: ${response.status}`);
        }
      } catch (googleError) {
        console.warn('Failed to sync with Google Sheets:', googleError);
        // Don't fail the whole operation, just log the warning
      }
      
      setLastClientData(data);
      setShowSuccess(true);
      form.reset({ 
        marketerId,
        clientName: '',
        clientPhone: '',
        propertyType: '',
        areaCity: '',
        unitCode: '',
        budgetRange: '',
        interestLevel: '',
        notes: '',
      });
      
      toast({
        title: "تم حفظ البيانات بنجاح",
        description: `تم تسجيل العميل ${data.clientName}`,
      });
    } catch (error: any) {
      toast({
        title: "خطأ في حفظ البيانات",
        description: error.message || "حدث خطأ أثناء حفظ البيانات",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleWhatsAppContact = () => {
    if (lastClientData) {
      const message = `مرحباً ${lastClientData.clientName}، أتواصل معك بخصوص ${lastClientData.propertyType} في ${lastClientData.areaCity}. كود الوحدة: ${lastClientData.unitCode}`;
      openWhatsApp(lastClientData.clientPhone, message);
    }
  };

  return (
    <>
      <Card className="shadow-lg border-0 bg-gradient-to-br from-white to-gray-50">
        <CardHeader className="bg-gradient-to-r from-green-600 to-green-700 text-white rounded-t-lg">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
              <User className="text-white" size={24} />
            </div>
            <div>
              <CardTitle className="text-2xl font-bold">
                تسجيل عميل جديد
              </CardTitle>
              <p className="text-green-100 mt-1">أدخل بيانات العميل بعناية</p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Client Name */}
            <div className="space-y-2">
              <Label htmlFor="clientName" className="flex items-center gap-2 text-gray-700 font-medium">
                <User className="h-5 w-5 text-green-600" />
                اسم العميل *
              </Label>
              <Input
                id="clientName"
                placeholder="الاسم الكامل للعميل"
                className="text-right border-2 border-gray-200 focus:border-green-500 rounded-lg p-3 text-lg"
                {...form.register('clientName')}
              />
              {form.formState.errors.clientName && (
                <p className="text-sm text-red-600 bg-red-50 p-2 rounded">
                  {form.formState.errors.clientName.message}
                </p>
              )}
            </div>

            {/* Client Phone */}
            <div className="space-y-2">
              <Label htmlFor="clientPhone" className="flex items-center gap-2 text-gray-700 font-medium">
                <Phone className="h-5 w-5 text-green-600" />
                رقم هاتف العميل *
              </Label>
              <Input
                id="clientPhone"
                type="tel"
                placeholder="01xxxxxxxxx"
                className="text-right border-2 border-gray-200 focus:border-green-500 rounded-lg p-3 text-lg"
                {...form.register('clientPhone')}
              />
              {form.formState.errors.clientPhone && (
                <p className="text-sm text-red-600 bg-red-50 p-2 rounded">
                  {form.formState.errors.clientPhone.message}
                </p>
              )}
            </div>

            {/* Property Type */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2 text-gray-700 font-medium">
                <Building className="h-5 w-5 text-green-600" />
                نوع العقار *
              </Label>
              <Select onValueChange={(value) => form.setValue('propertyType', value)}>
                <SelectTrigger className="text-right border-2 border-gray-200 focus:border-green-500 rounded-lg p-3 text-lg h-12">
                  <SelectValue placeholder="اختر نوع العقار" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="شقة">شقة</SelectItem>
                  <SelectItem value="أرض">أرض</SelectItem>
                  <SelectItem value="شاليه">شاليه</SelectItem>
                  <SelectItem value="فيلا">فيلا</SelectItem>
                  <SelectItem value="دوبلكس">دوبلكس</SelectItem>
                  <SelectItem value="تجاري">تجاري</SelectItem>
                </SelectContent>
              </Select>
              {form.formState.errors.propertyType && (
                <p className="text-sm text-red-600 bg-red-50 p-2 rounded">
                  {form.formState.errors.propertyType.message}
                </p>
              )}
            </div>

            {/* Area/City */}
            <div className="space-y-2">
              <Label htmlFor="areaCity" className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-primary" />
                المنطقة / المدينة *
              </Label>
              <Input
                id="areaCity"
                placeholder="مثال: القاهرة الجديدة، الشيخ زايد"
                className="text-right"
                {...form.register('areaCity')}
              />
              {form.formState.errors.areaCity && (
                <p className="text-sm text-destructive">
                  {form.formState.errors.areaCity.message}
                </p>
              )}
            </div>

            {/* Unit Code */}
            <div className="space-y-2">
              <Label htmlFor="unitCode" className="flex items-center gap-2">
                <Hash className="h-4 w-4 text-primary" />
                كود الوحدة *
              </Label>
              <Input
                id="unitCode"
                placeholder="مثال: A-101، B-205"
                className="text-right"
                {...form.register('unitCode')}
              />
              {form.formState.errors.unitCode && (
                <p className="text-sm text-destructive">
                  {form.formState.errors.unitCode.message}
                </p>
              )}
            </div>

            {/* Budget Range */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <DollarSign className="h-4 w-4 text-primary" />
                الميزانية المتوقعة
              </Label>
              <Select onValueChange={(value) => form.setValue('budgetRange', value)}>
                <SelectTrigger className="text-right">
                  <SelectValue placeholder="اختر نطاق الميزانية" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="أقل من مليون">أقل من مليون جنيه</SelectItem>
                  <SelectItem value="1-2 مليون">1-2 مليون جنيه</SelectItem>
                  <SelectItem value="2-3 مليون">2-3 مليون جنيه</SelectItem>
                  <SelectItem value="3-5 مليون">3-5 مليون جنيه</SelectItem>
                  <SelectItem value="أكثر من 5 مليون">أكثر من 5 مليون جنيه</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Interest Level */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Star className="h-4 w-4 text-primary" />
                مستوى الاهتمام
              </Label>
              <Select onValueChange={(value) => form.setValue('interestLevel', value)}>
                <SelectTrigger className="text-right">
                  <SelectValue placeholder="اختر مستوى الاهتمام" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="مهتم جداً">مهتم جداً</SelectItem>
                  <SelectItem value="مهتم">مهتم</SelectItem>
                  <SelectItem value="مهتم نوعاً ما">مهتم نوعاً ما</SelectItem>
                  <SelectItem value="يستطلع فقط">يستطلع فقط</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Notes */}
            <div className="space-y-2">
              <Label htmlFor="notes" className="flex items-center gap-2">
                <FileText className="h-4 w-4 text-primary" />
                ملاحظات إضافية
              </Label>
              <Textarea
                id="notes"
                rows={3}
                placeholder="أي ملاحظات أو تفاصيل إضافية..."
                className="text-right resize-none"
                {...form.register('notes')}
              />
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-bold py-4 text-lg rounded-lg shadow-lg transition-all duration-200 transform hover:scale-105"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  جاري الحفظ...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-5 w-5" />
                  📤 حفظ بيانات العميل
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Success Dialog */}
      <Dialog open={showSuccess} onOpenChange={setShowSuccess}>
        <DialogContent className="text-center">
          <DialogHeader>
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="text-green-500 text-2xl" size={32} />
            </div>
            <DialogTitle className="text-lg font-semibold text-text-primary">
              تم بنجاح!
            </DialogTitle>
            <DialogDescription className="text-text-secondary mb-6">
              تم حفظ بيانات العميل بنجاح
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-2">
            <Button
              onClick={handleWhatsAppContact}
              className="flex-1 bg-green-500 hover:bg-green-600"
            >
              <svg className="w-4 h-4 ml-2" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488z"/>
              </svg>
              واتساب
            </Button>
            <Button
              onClick={() => setShowSuccess(false)}
              variant="outline"
              className="flex-1"
            >
              تم
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
