import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Client } from '@shared/schema';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { RefreshCw, Search, Users } from 'lucide-react';
import { formatDate, getStatusColor, openWhatsApp } from '@/lib/utils';

interface ClientHistoryProps {
  marketerId: number;
}

export default function ClientHistory({ marketerId }: ClientHistoryProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const { data: clients, isLoading, refetch, isRefetching } = useQuery<Client[]>({
    queryKey: ['/api/clients', marketerId],
    refetchOnWindowFocus: false,
  });

  const filteredClients = clients?.filter(client => {
    const matchesSearch = client.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         client.clientPhone.includes(searchTerm);
    const matchesStatus = !statusFilter || statusFilter === 'all' || client.status === statusFilter;
    return matchesSearch && matchesStatus;
  }) || [];

  const handleWhatsAppContact = (client: Client) => {
    const message = `مرحباً ${client.clientName}، أتواصل معك بخصوص ${client.propertyType} في ${client.areaCity}. كود الوحدة: ${client.unitCode}`;
    openWhatsApp(client.clientPhone, message);
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-8 w-48" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="bg-gradient-to-r from-primary to-primary-dark text-white p-6 -m-6 mb-4 rounded-t-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Users className="text-2xl" size={24} />
              <div>
                <CardTitle className="text-xl font-bold text-white">
                  تاريخ العملاء
                </CardTitle>
                <p className="text-primary-light">جميع العملاء المسجلين</p>
              </div>
            </div>
            <Button
              onClick={() => refetch()}
              disabled={isRefetching}
              variant="ghost"
              className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white"
            >
              <RefreshCw className={`ml-2 h-4 w-4 ${isRefetching ? 'animate-spin' : ''}`} />
              تحديث
            </Button>
          </div>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="بحث بالاسم أو رقم الهاتف..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="text-right pr-10"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-48 text-right">
              <SelectValue placeholder="جميع الحالات" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع الحالات</SelectItem>
              <SelectItem value="جاري المتابعة">جاري المتابعة</SelectItem>
              <SelectItem value="تم التواصل">تم التواصل</SelectItem>
              <SelectItem value="مهتم">مهتم</SelectItem>
              <SelectItem value="غير مهتم">غير مهتم</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>

      <CardContent>
        {filteredClients.length === 0 ? (
          <div className="text-center py-12">
            <Users className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground">
              {clients?.length === 0 
                ? 'لا توجد بيانات عملاء حتى الآن' 
                : 'لا توجد نتائج للبحث الحالي'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <div className="hidden sm:block">
              <table className="w-full">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase">
                      اسم العميل
                    </th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase">
                      رقم الهاتف
                    </th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase">
                      نوع العقار
                    </th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase">
                      المدينة
                    </th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase">
                      كود الوحدة
                    </th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase">
                      الحالة
                    </th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase">
                      التاريخ
                    </th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase">
                      إجراءات
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filteredClients.map((client) => (
                    <tr key={client.id} className="hover:bg-muted/25">
                      <td className="px-4 py-4 text-sm font-medium text-foreground">
                        {client.clientName}
                      </td>
                      <td className="px-4 py-4 text-sm text-muted-foreground">
                        {client.clientPhone}
                      </td>
                      <td className="px-4 py-4 text-sm text-muted-foreground">
                        {client.propertyType}
                      </td>
                      <td className="px-4 py-4 text-sm text-muted-foreground">
                        {client.areaCity}
                      </td>
                      <td className="px-4 py-4 text-sm text-muted-foreground">
                        {client.unitCode}
                      </td>
                      <td className="px-4 py-4">
                        <Badge className={getStatusColor(client.status || 'جاري المتابعة')}>
                          {client.status || 'جاري المتابعة'}
                        </Badge>
                      </td>
                      <td className="px-4 py-4 text-sm text-muted-foreground">
                        {formatDate(client.createdAt!)}
                      </td>
                      <td className="px-4 py-4">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleWhatsAppContact(client)}
                          className="text-green-600 hover:text-green-700 hover:bg-green-50"
                        >
                          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488z"/>
                          </svg>
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile view */}
            <div className="sm:hidden space-y-4">
              {filteredClients.map((client) => (
                <div key={client.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium text-foreground">{client.clientName}</h3>
                      <p className="text-sm text-muted-foreground">{client.clientPhone}</p>
                    </div>
                    <Badge className={getStatusColor(client.status || 'جاري المتابعة')}>
                      {client.status || 'جاري المتابعة'}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="text-muted-foreground">العقار: </span>
                      <span>{client.propertyType}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">المدينة: </span>
                      <span>{client.areaCity}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">الكود: </span>
                      <span>{client.unitCode}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">التاريخ: </span>
                      <span>{formatDate(client.createdAt!)}</span>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => handleWhatsAppContact(client)}
                    className="w-full bg-green-500 hover:bg-green-600"
                  >
                    <svg className="w-4 h-4 ml-2" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488z"/>
                    </svg>
                    تواصل عبر واتساب
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
