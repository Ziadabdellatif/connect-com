import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Marketer } from '@shared/schema';

interface AuthContextType {
  marketer: Marketer | null;
  login: (marketer: Marketer) => void;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [marketer, setMarketer] = useState<Marketer | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const savedMarketer = localStorage.getItem('currentMarketer');
    if (savedMarketer) {
      try {
        const marketerData = JSON.parse(savedMarketer);
        setMarketer(marketerData);
      } catch (error) {
        console.error('Failed to parse saved marketer data:', error);
        localStorage.removeItem('currentMarketer');
      }
    }
    setIsLoading(false);
  }, []);

  const login = (marketerData: Marketer) => {
    setMarketer(marketerData);
    localStorage.setItem('currentMarketer', JSON.stringify(marketerData));
  };

  const logout = () => {
    setMarketer(null);
    localStorage.removeItem('currentMarketer');
  };

  return (
    <AuthContext.Provider value={{ marketer, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
