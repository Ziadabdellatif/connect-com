import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import Dashboard from "@/pages/Dashboard";
import AdminDashboard from "@/pages/AdminDashboard";

function AuthenticatedRoute({ children }: { children: React.ReactNode }) {
  const { marketer, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-surface">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  if (!marketer) {
    return <Redirect to="/" />;
  }
  
  return <>{children}</>;
}

function UnauthenticatedRoute({ children }: { children: React.ReactNode }) {
  const { marketer, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-surface">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  if (marketer) {
    return <Redirect to="/dashboard" />;
  }
  
  return <>{children}</>;
}

function Router() {
  return (
    <Switch>
      <Route path="/">
        <UnauthenticatedRoute>
          <Login />
        </UnauthenticatedRoute>
      </Route>
      <Route path="/register">
        <UnauthenticatedRoute>
          <Register />
        </UnauthenticatedRoute>
      </Route>
      <Route path="/dashboard">
        <AuthenticatedRoute>
          <Dashboard />
        </AuthenticatedRoute>
      </Route>
      <Route path="/admin">
        <AuthenticatedRoute>
          <AdminDashboard />
        </AuthenticatedRoute>
      </Route>
      {/* Redirect any other route to login */}
      <Route>
        <Redirect to="/" />
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
