import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  Shield, 
  Users, 
  UserCheck, 
  BarChart3, 
  TrendingUp, 
  Phone, 
  MapPin, 
  Building,
  Hash,
  Calendar,
  Search,
  Filter,
  RefreshCw,
  Edit,
  LogOut
} from 'lucide-react';
import { formatDate, getStatusColor, openWhatsApp } from '@/lib/utils';

interface ClientWithMarketer {
  id: number;
  marketerId: number;
  clientName: string;
  clientPhone: string;
  propertyType: string;
  areaCity: string;
  unitCode: string;
  budgetRange?: string;
  interestLevel?: string;
  notes?: string;
  status?: string;
  createdAt: string;
  marketerName: string;
}

interface Marketer {
  id: number;
  name: string;
  phone: string;
  isActive: boolean;
  isAdmin: boolean;
  createdAt: string;
}

export default function AdminDashboard() {
  const { marketer, logout } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedClient, setSelectedClient] = useState<ClientWithMarketer | null>(null);
  const [newStatus, setNewStatus] = useState('');

  const { data: clients = [], isLoading: loadingClients, refetch: refetchClients } = useQuery<ClientWithMarketer[]>({
    queryKey: ['/api/admin/clients'],
    refetchOnWindowFocus: false,
  });

  const { data: marketers = [], isLoading: loadingMarketers } = useQuery<Marketer[]>({
    queryKey: ['/api/admin/marketers'],
    refetchOnWindowFocus: false,
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ clientId, status }: { clientId: number; status: string }) => {
      const response = await apiRequest('PATCH', `/api/clients/${clientId}`, { status });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/clients'] });
      toast({
        title: "تم تحديث الحالة",
        description: "تم تحديث حالة العميل بنجاح",
      });
      setSelectedClient(null);
      setNewStatus('');
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في التحديث",
        description: error.message || "فشل في تحديث حالة العميل",
        variant: "destructive",
      });
    },
  });

  if (!marketer?.isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 text-center">
            <Shield className="mx-auto h-12 w-12 text-red-500 mb-4" />
            <h2 className="text-xl font-bold text-gray-900 mb-2">غير مصرح</h2>
            <p className="text-gray-600 mb-4">لا تملك صلاحيات للوصول لهذه الصفحة</p>
            <Button onClick={logout} variant="outline">
              العودة لتسجيل الدخول
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const filteredClients = clients.filter(client => {
    const matchesSearch = client.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         client.clientPhone.includes(searchTerm) ||
                         client.marketerName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = !statusFilter || statusFilter === 'all' || client.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const statusCounts = {
    total: clients.length,
    pending: clients.filter(c => c.status === 'جاري المتابعة').length,
    contacted: clients.filter(c => c.status === 'تم التواصل').length,
    interested: clients.filter(c => c.status === 'مهتم').length,
    notInterested: clients.filter(c => c.status === 'غير مهتم').length,
  };

  const handleStatusUpdate = () => {
    if (selectedClient && newStatus) {
      updateStatusMutation.mutate({
        clientId: selectedClient.id,
        status: newStatus,
      });
    }
  };

  const handleWhatsAppContact = (client: ClientWithMarketer) => {
    const message = `مرحباً ${client.clientName}، أتواصل معك بخصوص ${client.propertyType} في ${client.areaCity}. كود الوحدة: ${client.unitCode}`;
    openWhatsApp(client.clientPhone, message);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center">
                <Shield className="text-white" size={20} />
              </div>
              <div className="mr-3">
                <h1 className="text-lg font-semibold text-gray-900">
                  لوحة التحكم الإدارية
                </h1>
                <p className="text-sm text-gray-600">{marketer.name} - مدير النظام</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={logout}
              className="text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-4">
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
            <TabsTrigger value="clients">إدارة العملاء</TabsTrigger>
            <TabsTrigger value="marketers">المسوقين</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">إجمالي العملاء</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{statusCounts.total}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">جاري المتابعة</CardTitle>
                  <TrendingUp className="h-4 w-4 text-yellow-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-yellow-600">{statusCounts.pending}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">تم التواصل</CardTitle>
                  <UserCheck className="h-4 w-4 text-blue-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600">{statusCounts.contacted}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">مهتم</CardTitle>
                  <BarChart3 className="h-4 w-4 text-green-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{statusCounts.interested}</div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>المسوقين النشطين</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-2">{marketers.filter(m => m.isActive).length}</div>
                <p className="text-sm text-gray-600">من أصل {marketers.length} مسوق مسجل</p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Clients Management Tab */}
          <TabsContent value="clients" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5" />
                      إدارة العملاء وتحديث الحالات
                    </CardTitle>
                    <p className="text-sm text-gray-600 mt-1">
                      عرض وإدارة جميع العملاء في النظام
                    </p>
                  </div>
                  <Button
                    onClick={() => refetchClients()}
                    disabled={loadingClients}
                    variant="outline"
                  >
                    <RefreshCw className={`ml-2 h-4 w-4 ${loadingClients ? 'animate-spin' : ''}`} />
                    تحديث
                  </Button>
                </div>

                {/* Search and Filter */}
                <div className="flex flex-col sm:flex-row gap-4 mt-4">
                  <div className="flex-1 relative">
                    <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="بحث بالاسم، الهاتف، أو المسوق..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="text-right pr-10"
                    />
                  </div>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-full sm:w-48 text-right">
                      <SelectValue placeholder="جميع الحالات" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">جميع الحالات</SelectItem>
                      <SelectItem value="جاري المتابعة">جاري المتابعة</SelectItem>
                      <SelectItem value="تم التواصل">تم التواصل</SelectItem>
                      <SelectItem value="مهتم">مهتم</SelectItem>
                      <SelectItem value="غير مهتم">غير مهتم</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent>
                {loadingClients ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto"></div>
                    <p className="mt-2 text-gray-600">جاري تحميل البيانات...</p>
                  </div>
                ) : filteredClients.length === 0 ? (
                  <div className="text-center py-8">
                    <Users className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <p className="text-gray-600">لا توجد عملاء مطابقين للبحث</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {filteredClients.map((client) => (
                      <div key={client.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div className="flex flex-col lg:flex-row justify-between items-start gap-4">
                          <div className="flex-1 space-y-2">
                            <div className="flex items-center gap-4">
                              <h3 className="font-semibold text-lg text-gray-900">{client.clientName}</h3>
                              <Badge className={getStatusColor(client.status || 'جاري المتابعة')}>
                                {client.status || 'جاري المتابعة'}
                              </Badge>
                            </div>
                            
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-sm">
                              <div className="flex items-center gap-2">
                                <Phone className="h-4 w-4 text-gray-500" />
                                <span>{client.clientPhone}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Building className="h-4 w-4 text-gray-500" />
                                <span>{client.propertyType}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <MapPin className="h-4 w-4 text-gray-500" />
                                <span>{client.areaCity}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Hash className="h-4 w-4 text-gray-500" />
                                <span>{client.unitCode}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Users className="h-4 w-4 text-gray-500" />
                                <span>{client.marketerName}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Calendar className="h-4 w-4 text-gray-500" />
                                <span>{formatDate(client.createdAt)}</span>
                              </div>
                            </div>

                            {client.notes && (
                              <div className="text-sm text-gray-600 bg-gray-50 p-2 rounded">
                                <strong>ملاحظات:</strong> {client.notes}
                              </div>
                            )}
                          </div>

                          <div className="flex flex-col sm:flex-row gap-2">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => setSelectedClient(client)}
                                >
                                  <Edit className="h-4 w-4 ml-1" />
                                  تحديث الحالة
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="text-right">
                                <DialogHeader>
                                  <DialogTitle>تحديث حالة العميل</DialogTitle>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <div>
                                    <p className="font-medium">{selectedClient?.clientName}</p>
                                    <p className="text-sm text-gray-600">{selectedClient?.clientPhone}</p>
                                  </div>
                                  <Select value={newStatus} onValueChange={setNewStatus}>
                                    <SelectTrigger className="text-right">
                                      <SelectValue placeholder="اختر الحالة الجديدة" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="جاري المتابعة">جاري المتابعة</SelectItem>
                                      <SelectItem value="تم التواصل">تم التواصل</SelectItem>
                                      <SelectItem value="مهتم">مهتم</SelectItem>
                                      <SelectItem value="غير مهتم">غير مهتم</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <Button 
                                    onClick={handleStatusUpdate}
                                    disabled={!newStatus || updateStatusMutation.isPending}
                                    className="w-full"
                                  >
                                    {updateStatusMutation.isPending ? 'جاري التحديث...' : 'تحديث الحالة'}
                                  </Button>
                                </div>
                              </DialogContent>
                            </Dialog>

                            <Button
                              size="sm"
                              onClick={() => handleWhatsAppContact(client)}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              <svg className="w-4 h-4 ml-1" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488z"/>
                              </svg>
                              واتساب
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Marketers Tab */}
          <TabsContent value="marketers" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserCheck className="h-5 w-5" />
                  قائمة المسوقين
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loadingMarketers ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto"></div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {marketers.map((marketer) => (
                      <div key={marketer.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <h3 className="font-medium">{marketer.name}</h3>
                          <p className="text-sm text-gray-600">{marketer.phone}</p>
                          <p className="text-xs text-gray-500">{formatDate(marketer.createdAt)}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          {marketer.isAdmin && (
                            <Badge variant="destructive">مدير</Badge>
                          )}
                          <Badge variant={marketer.isActive ? "default" : "secondary"}>
                            {marketer.isActive ? "نشط" : "غير نشط"}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}