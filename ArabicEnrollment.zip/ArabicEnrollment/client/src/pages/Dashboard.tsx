import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LogOut, User, Plus, History, Shield } from 'lucide-react';
import { Link } from 'wouter';
import ClientForm from '@/components/ClientForm';
import ClientHistory from '@/components/ClientHistory';

export default function Dashboard() {
  const { marketer, logout } = useAuth();
  const [activeTab, setActiveTab] = useState('new-client');

  const handleLogout = () => {
    logout();
  };

  if (!marketer) return null;

  return (
    <div className="min-h-screen bg-surface">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center">
                <User className="text-white" size={20} />
              </div>
              <div className="mr-3">
                <h1 className="text-lg font-semibold text-gray-900">
                  مرحباً، {marketer.name}
                </h1>
                <p className="text-sm text-gray-600">{marketer.phone}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {marketer.isAdmin && (
                <Link href="/admin">
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-red-600 border-red-600 hover:bg-red-50"
                  >
                    <Shield className="h-4 w-4 mr-1" />
                    لوحة الإدارة
                  </Button>
                </Link>
              )}
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLogout}
                className="text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="new-client" className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              عميل جديد
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2">
              <History className="h-4 w-4" />
              تاريخ العملاء
            </TabsTrigger>
          </TabsList>

          <TabsContent value="new-client" className="animate-fade-in">
            <ClientForm marketerId={marketer.id} />
          </TabsContent>

          <TabsContent value="history" className="animate-fade-in">
            <ClientHistory marketerId={marketer.id} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
