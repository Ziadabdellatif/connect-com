import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const marketers = pgTable("marketers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull().unique(),
  password: text("password").notNull(),
  isActive: boolean("is_active").default(true),
  isAdmin: boolean("is_admin").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const clients = pgTable("clients", {
  id: serial("id").primaryKey(),
  marketerId: integer("marketer_id").notNull(),
  clientName: text("client_name").notNull(),
  clientPhone: text("client_phone").notNull(),
  propertyType: text("property_type").notNull(),
  areaCity: text("area_city").notNull(),
  unitCode: text("unit_code").notNull(),
  budgetRange: text("budget_range"),
  interestLevel: text("interest_level"),
  notes: text("notes"),
  status: text("status").default("جاري المتابعة"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const marketersRelations = relations(marketers, ({ many }) => ({
  clients: many(clients),
}));

export const clientsRelations = relations(clients, ({ one }) => ({
  marketer: one(marketers, {
    fields: [clients.marketerId],
    references: [marketers.id],
  }),
}));

export const insertMarketerSchema = createInsertSchema(marketers).omit({
  id: true,
  createdAt: true,
});

export const insertClientSchema = createInsertSchema(clients).omit({
  id: true,
  createdAt: true,
});

export const loginSchema = z.object({
  phone: z.string().regex(/^01\d{9}$/, "يجب أن يبدأ الرقم بـ 01 ويتكون من 11 رقمًا"),
  password: z.string().min(4, "كلمة المرور قصيرة جداً"),
});

export type InsertMarketer = z.infer<typeof insertMarketerSchema>;
export type InsertClient = z.infer<typeof insertClientSchema>;
export type Marketer = typeof marketers.$inferSelect;
export type Client = typeof clients.$inferSelect;
export type LoginData = z.infer<typeof loginSchema>;
