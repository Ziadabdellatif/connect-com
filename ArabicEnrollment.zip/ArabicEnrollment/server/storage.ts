import { marketers, clients, type Marketer, type Client, type InsertMarketer, type InsertClient } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getMarketer(id: number): Promise<Marketer | undefined>;
  getMarketerByPhone(phone: string): Promise<Marketer | undefined>;
  createMarketer(insertMarketer: InsertMarketer): Promise<Marketer>;
  createClient(insertClient: InsertClient): Promise<Client>;
  getClientsByMarketer(marketerId: number): Promise<Client[]>;
  updateClientStatus(clientId: number, status: string): Promise<Client | undefined>;
  getAllClients(): Promise<Client[]>;
  getAllMarketers(): Promise<Marketer[]>;
  getClientsWithMarketerInfo(): Promise<(Client & { marketerName: string })[]>;
}

export class DatabaseStorage implements IStorage {
  async getMarketer(id: number): Promise<Marketer | undefined> {
    const [marketer] = await db.select().from(marketers).where(eq(marketers.id, id));
    return marketer || undefined;
  }

  async getMarketerByPhone(phone: string): Promise<Marketer | undefined> {
    const [marketer] = await db.select().from(marketers).where(eq(marketers.phone, phone));
    return marketer || undefined;
  }

  async createMarketer(insertMarketer: InsertMarketer): Promise<Marketer> {
    const [marketer] = await db
      .insert(marketers)
      .values(insertMarketer)
      .returning();
    return marketer;
  }

  async createClient(insertClient: InsertClient): Promise<Client> {
    const [client] = await db
      .insert(clients)
      .values(insertClient)
      .returning();
    return client;
  }

  async getClientsByMarketer(marketerId: number): Promise<Client[]> {
    return await db.select().from(clients).where(eq(clients.marketerId, marketerId));
  }

  async updateClientStatus(clientId: number, status: string): Promise<Client | undefined> {
    const [client] = await db
      .update(clients)
      .set({ status })
      .where(eq(clients.id, clientId))
      .returning();
    return client || undefined;
  }

  async getAllClients(): Promise<Client[]> {
    return await db.select().from(clients);
  }

  async getAllMarketers(): Promise<Marketer[]> {
    return await db.select().from(marketers);
  }

  async getClientsWithMarketerInfo(): Promise<(Client & { marketerName: string })[]> {
    const result = await db
      .select({
        id: clients.id,
        marketerId: clients.marketerId,
        clientName: clients.clientName,
        clientPhone: clients.clientPhone,
        propertyType: clients.propertyType,
        areaCity: clients.areaCity,
        unitCode: clients.unitCode,
        budgetRange: clients.budgetRange,
        interestLevel: clients.interestLevel,
        notes: clients.notes,
        status: clients.status,
        createdAt: clients.createdAt,
        marketerName: marketers.name,
      })
      .from(clients)
      .leftJoin(marketers, eq(clients.marketerId, marketers.id));
    
    return result as (Client & { marketerName: string })[];
  }
}

export const storage = new DatabaseStorage();