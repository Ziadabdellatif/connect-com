import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMarketerSchema, insertClientSchema, loginSchema } from "@shared/schema";
import bcrypt from "bcrypt";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Register new marketer
  app.post("/api/register", async (req, res) => {
    try {
      const data = insertMarketerSchema.parse(req.body);
      
      // Check if phone already exists
      const existingMarketer = await storage.getMarketerByPhone(data.phone);
      if (existingMarketer) {
        return res.status(400).json({ message: "رقم الهاتف مسجل بالفعل" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(data.password, 10);
      
      // Check if this is the first marketer to make them admin
      const allMarketers = await storage.getAllMarketers();
      const isFirstMarketer = allMarketers.length === 0;
      
      const marketer = await storage.createMarketer({
        ...data,
        password: hashedPassword,
        isAdmin: isFirstMarketer,
      });

      // Don't send password back
      const { password, ...safeMarketer } = marketer;
      res.json(safeMarketer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "حدث خطأ في الخادم" });
    }
  });

  // Login marketer
  app.post("/api/login", async (req, res) => {
    try {
      const { phone, password } = loginSchema.parse(req.body);
      
      const marketer = await storage.getMarketerByPhone(phone);
      if (!marketer) {
        return res.status(401).json({ message: "رقم الهاتف أو كلمة المرور غير صحيح" });
      }

      const validPassword = await bcrypt.compare(password, marketer.password);
      if (!validPassword) {
        return res.status(401).json({ message: "رقم الهاتف أو كلمة المرور غير صحيح" });
      }

      if (!marketer.isActive) {
        return res.status(401).json({ message: "الحساب غير مفعل" });
      }

      // Don't send password back
      const { password: _, ...safeMarketer } = marketer;
      res.json(safeMarketer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "حدث خطأ في الخادم" });
    }
  });

  // Create new client
  app.post("/api/clients", async (req, res) => {
    try {
      const data = insertClientSchema.parse(req.body);
      
      // Verify marketer exists
      const marketer = await storage.getMarketer(data.marketerId);
      if (!marketer) {
        return res.status(404).json({ message: "المسوق غير موجود" });
      }

      const client = await storage.createClient(data);
      res.json(client);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "حدث خطأ في الخادم" });
    }
  });

  // Get clients for a marketer
  app.get("/api/clients/:marketerId", async (req, res) => {
    try {
      const marketerId = parseInt(req.params.marketerId);
      const clients = await storage.getClientsByMarketer(marketerId);
      res.json(clients);
    } catch (error) {
      res.status(500).json({ message: "حدث خطأ في الخادم" });
    }
  });

  // Update client status
  app.patch("/api/clients/:clientId", async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const { status } = req.body;
      
      const client = await storage.updateClientStatus(clientId, status);
      if (!client) {
        return res.status(404).json({ message: "العميل غير موجود" });
      }
      
      res.json(client);
    } catch (error) {
      res.status(500).json({ message: "حدث خطأ في الخادم" });
    }
  });

  // Admin routes
  app.get("/api/admin/clients", async (req, res) => {
    try {
      const clients = await storage.getClientsWithMarketerInfo();
      res.json(clients);
    } catch (error) {
      res.status(500).json({ message: "حدث خطأ في الخادم" });
    }
  });

  app.get("/api/admin/marketers", async (req, res) => {
    try {
      const marketers = await storage.getAllMarketers();
      res.json(marketers);
    } catch (error) {
      res.status(500).json({ message: "حدث خطأ في الخادم" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
